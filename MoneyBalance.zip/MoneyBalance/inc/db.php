<?php
// Koneksi ke SQLite
$db = new SQLite3(__DIR__ . '/../db/database.sqlite');
if(!$db) {
    die('Database connection failed');
}
?>