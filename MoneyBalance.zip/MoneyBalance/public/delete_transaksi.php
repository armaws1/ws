<?php
session_start();
include_once '../inc/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'] ?? 0;
$stmt = $db->prepare("DELETE FROM transaksi WHERE id = ? AND user_id = ?");
$stmt->bindValue(1, $id, SQLITE3_INTEGER);
$stmt->bindValue(2, $_SESSION['user_id'], SQLITE3_INTEGER);
$stmt->execute();

header("Location: transaksi.php?delete=1");
exit;