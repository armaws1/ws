<?php
$db = new SQLite3(__DIR__ . '/db/database.sqlite');

// Tabel user
$db->exec("CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT,
    role TEXT DEFAULT 'user'
)");

// Tabel transaksi
$db->exec("CREATE TABLE IF NOT EXISTS transaksi (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    jenis TEXT,
    nominal INTEGER,
    keterangan TEXT,
    tanggal TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id)
)");

echo "Setup selesai! Tabel berhasil dibuat.";
?>