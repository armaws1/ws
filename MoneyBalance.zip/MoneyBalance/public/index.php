<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}
$username = $_SESSION['username'];
?>
<link rel="stylesheet" href="style.css">
<div class="navbar">
    <a href="index.php">Dashboard</a>
    <a href="transaksi.php">Transaksi</a>
    <a href="logout.php">Logout</a>
</div>
<div class="container">
    <h2>Selamat datang, <?= htmlspecialchars($username) ?> 👋</h2>
    <p>Kelola catatan keuanganmu dengan mudah!</p>
    <img src="https://cdn-icons-png.flaticon.com/512/3135/3135715.png" alt="Dashboard" style="width:120px; margin:25px 0;">
</div>