<?php
session_start();
include_once '../inc/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$result = $db->query("SELECT t.*, u.username FROM transaksi t JOIN users u ON t.user_id = u.id ORDER BY t.tanggal DESC, t.id DESC");
?>
<link rel="stylesheet" href="style.css">
<div class="navbar">
    <a href="admin.php">Dashboard Admin</a>
    <a href="logout.php">Logout</a>
</div>
<div class="container">
    <h2>Rekap Semua Transaksi</h2>
    <div class="table-responsive">
    <table>
        <tr>
            <th>User</th>
            <th>Jenis</th>
            <th>Nominal</th>
            <th>Keterangan</th>
            <th>Tanggal</th>
        </tr>
        <?php while ($row = $result->fetchArray(SQLITE3_ASSOC)): ?>
            <tr>
                <td><?= htmlspecialchars($row['username']) ?></td>
                <td><?= ucfirst($row['jenis']) ?></td>
                <td>Rp<?= number_format($row['nominal'],0,',','.') ?></td>
                <td><?= htmlspecialchars($row['keterangan']) ?></td>
                <td><?= $row['tanggal'] ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
    </div>
</div>