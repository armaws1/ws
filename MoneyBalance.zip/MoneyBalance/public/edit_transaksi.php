<?php
session_start();
include_once '../inc/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'] ?? 0;

$stmt = $db->prepare("SELECT * FROM transaksi WHERE id = ? AND user_id = ?");
$stmt->bindValue(1, $id, SQLITE3_INTEGER);
$stmt->bindValue(2, $_SESSION['user_id'], SQLITE3_INTEGER);
$row = $stmt->execute()->fetchArray(SQLITE3_ASSOC);

if (!$row) {
    $error = "Transaksi tidak ditemukan.";
}

// Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jenis = $_POST['jenis'];
    $nominal = $_POST['nominal'];
    $keterangan = $_POST['keterangan'];

    $stmt = $db->prepare("UPDATE transaksi SET jenis = ?, nominal = ?, keterangan = ? WHERE id = ?");
    $stmt->bindValue(1, $jenis, SQLITE3_TEXT);
    $stmt->bindValue(2, $nominal, SQLITE3_INTEGER);
    $stmt->bindValue(3, $keterangan, SQLITE3_TEXT);
    $stmt->bindValue(4, $id, SQLITE3_INTEGER);
    $stmt->execute();
    header("Location: transaksi.php?update=1");
    exit;
}
?>
<link rel="stylesheet" href="style.css">
<div class="navbar">
    <a href="index.php">Dashboard</a>
    <a href="transaksi.php">Transaksi</a>
    <a href="logout.php">Logout</a>
</div>
<div class="container">
    <h2>Edit Transaksi</h2>
    <?php if(isset($error)): ?>
      <div class="error"><?= $error ?></div>
    <?php else: ?>
    <form method="POST" style="flex-direction:column;align-items:stretch;">
        <label>Jenis</label>
        <select name="jenis">
            <option value="pemasukan" <?= $row['jenis']=='pemasukan'?'selected':'' ?>>Pemasukan</option>
            <option value="pengeluaran" <?= $row['jenis']=='pengeluaran'?'selected':'' ?>>Pengeluaran</option>
        </select>
        <label>Nominal</label>
        <input type="number" name="nominal" value="<?= $row['nominal'] ?>" required>
        <label>Keterangan</label>
        <input type="text" name="keterangan" value="<?= htmlspecialchars($row['keterangan']) ?>">
        <button type="submit">Update</button>
        <a href="transaksi.php" class="btn" style="background:#aaa;">Batal</a>
    </form>
    <?php endif; ?>
</div>