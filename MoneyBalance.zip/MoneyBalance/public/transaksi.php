<?php
session_start();
include_once '../inc/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'user') {
    header("Location: login.php");
    exit;
}

// CREATE
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jenis = $_POST['jenis'];
    $nominal = $_POST['nominal'];
    $keterangan = $_POST['keterangan'];
    $tanggal = date('Y-m-d');

    $stmt = $db->prepare("INSERT INTO transaksi (user_id, jenis, nominal, keterangan, tanggal) VALUES (?, ?, ?, ?, ?)");
    $stmt->bindValue(1, $_SESSION['user_id'], SQLITE3_INTEGER);
    $stmt->bindValue(2, $jenis, SQLITE3_TEXT);
    $stmt->bindValue(3, $nominal, SQLITE3_INTEGER);
    $stmt->bindValue(4, $keterangan, SQLITE3_TEXT);
    $stmt->bindValue(5, $tanggal, SQLITE3_TEXT);
    $stmt->execute();
    header("Location: transaksi.php?success=1");
    exit;
}

// READ
$result = $db->query("SELECT * FROM transaksi WHERE user_id = " . $_SESSION['user_id'] . " ORDER BY tanggal DESC, id DESC");
?>
<link rel="stylesheet" href="style.css">
<div class="navbar">
    <a href="index.php">Dashboard</a>
    <a href="transaksi.php">Transaksi</a>
    <a href="logout.php">Logout</a>
</div>
<div class="container">
    <h2>Catatan Transaksi</h2>
    <?php if(isset($_GET['success'])): ?>
      <div class="success">Transaksi berhasil ditambahkan!</div>
    <?php endif; ?>
    <form method="POST">
        <label>Jenis</label>
        <select name="jenis">
            <option value="pemasukan">Pemasukan</option>
            <option value="pengeluaran">Pengeluaran</option>
        </select>
        <label>Nominal</label>
        <input type="number" name="nominal" required>
        <label>Keterangan</label>
        <input type="text" name="keterangan" maxlength="50">
        <button type="submit">Tambah Transaksi</button>
    </form>

    <div class="table-responsive">
    <table>
        <tr><th>Jenis</th><th>Nominal</th><th>Keterangan</th><th>Tanggal</th><th>Aksi</th></tr>
        <?php while ($row = $result->fetchArray(SQLITE3_ASSOC)): ?>
            <tr>
                <td><?= ucfirst($row['jenis']) ?></td>
                <td>Rp<?= number_format($row['nominal'],0,',','.') ?></td>
                <td><?= htmlspecialchars($row['keterangan']) ?></td>
                <td><?= $row['tanggal'] ?></td>
                <td class="action-btns">
                    <a href="edit_transaksi.php?id=<?= $row['id'] ?>" class="edit">Edit</a>
                    <a href="delete_transaksi.php?id=<?= $row['id'] ?>" class="delete" onclick="return confirm('Yakin hapus?')">Hapus</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
    </div>
</div>